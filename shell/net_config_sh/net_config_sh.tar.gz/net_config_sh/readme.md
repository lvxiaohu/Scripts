# 1. 此脚本只支持CentOS/RHEL 7.x
# 2. 下载脚本执行 $bash setup_net.sh 安装
# 3. 输入 $config 对网卡进行配置
